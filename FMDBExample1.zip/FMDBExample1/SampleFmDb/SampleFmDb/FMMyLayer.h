//
//  FMMyLayer.h
//  SampleFmDb
//
//  Created by Vladamir Nedelko on 1/5/17.
//  Copyright © 2017 Vladamir Nedelko. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import <sqlite3ext.h>
#import "FMDatabase.h"



@interface FMMyLayer : NSObject

- (id)init;

- (void)initTable;

- (void)insertData:(NSString *)qr;

- (NSArray *)selectData:(NSString *)qry;


@end
