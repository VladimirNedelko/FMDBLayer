//
//  ReadViewController.swift
//  SampleFmDb
//
//  Created by Vladamir Nedelko on 1/5/17.
//  Copyright © 2017 Vladamir Nedelko. All rights reserved.
//

import UIKit

class ReadViewController: UIViewController, UITableViewDelegate, UITableViewDataSource  {
    
    @IBOutlet weak var tblView: UITableView!
    
    @IBOutlet weak var btnDismiss: UIButton!
    
    let fmlayer:FMMyLayer = FMMyLayer();
    var resultset:NSArray?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tblView.delegate = self
        tblView.dataSource = self
        
        btnDismiss.addTarget(self, action: #selector(removeViewFromScreen), for: .touchUpInside)
        
        resultset = fmlayer.selectData("SELECT * FROM Sample") as NSArray
        
        // print(result)
    }
    
    
    func removeViewFromScreen(){
        
        self.dismiss(animated: true, completion:nil)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return (resultset?.count)!
    }
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:MyTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cellid") as! MyTableViewCell
        
        let book:NSDictionary = resultset?.object(at: indexPath.row) as! NSDictionary
        let fname = book.value(forKey: "First")
        let name =  book.value(forKey: "Last")
        let mid = book.value(forKey: "Middle")
        
        cell.lblFirst.text =  fname as? String
        cell.lblLast.text =  name as? String
        cell.lblMidle.text = mid as? String
        
        return cell
    }

    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
