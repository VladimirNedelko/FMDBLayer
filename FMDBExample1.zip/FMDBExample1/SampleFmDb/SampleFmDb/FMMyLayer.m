//
//  FMMyLayer.m
//  SampleFmDb
//
//  Created by Vladamir Nedelko on 1/5/17.
//  Copyright © 2017 Vladamir Nedelko. All rights reserved.
//



#import "FMMyLayer.h"



@implementation FMMyLayer

- (id)init{
    
    self = [super init];
    
    if (self ){
    
    }
    
    
    return  self;
}


- (void)insertData:(NSString *)qr {
    
    FMDatabase *db = [self connectToDb];
    
    if ([db open])
    {
        NSString *str = qr;
        
        [db beginTransaction];
        
        BOOL success = [db executeUpdate:str];
        
        [db  commit];
        
        [db close];
    }

}


- (NSArray *)selectData:(NSString *)qry
{
    
    FMDatabase *db = [self connectToDb];
    
    FMResultSet *result;
    
    NSMutableArray *arResult = [[NSMutableArray alloc] init];
    
    if ([db open])
    {
        [db beginTransaction];
        
        result = [db executeQuery:qry];
        
        while ([result next])
        {
            [arResult addObject:[result resultDictionary]];
        }
    }
    
    [db close];
    
    NSArray *ar = [NSArray arrayWithArray:arResult];
    return ar;
}



- (void)initTable{
    
    NSString *tbl = @"Sample";
    
    BOOL tblExist =  [self checkIfTableExists:tbl];
    
    if (!tblExist)
    {
        NSString *str = @" Create Table Sample ("
        "First Text,"
        "Last Text, Middle Text )";
        
        FMDatabase *db = [self connectToDb];
        
        if ([db open])
        {
            //NSString *str = qryStr;
            
            [db beginTransaction];
            
            BOOL success = [db executeUpdate:str];
            // if success
            [db  commit];
            
            [db close];
        }
    }

    
}



- (BOOL)checkIfTableExists:(NSString *)tbl  // good
{
    BOOL exists = NO;
    
    NSString *qry = [NSString stringWithFormat:@"SELECT name FROM sqlite_master WHERE name='%@' ", tbl];
    FMDatabase *db = [self connectToDb];
    
    if ([db open])
    {
        [db beginTransaction];
        FMResultSet *rslt  = [db executeQuery:qry];
        while ([rslt next])
        {
            exists = YES;
        }
    }
    
    [db close];
    
    return exists;
}


- (FMDatabase *)connectToDb
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *writableDBPath = [documentsDirectory stringByAppendingPathComponent:@"Data.sqlite"];
    FMDatabase* db = [FMDatabase databaseWithPath:writableDBPath];
    
    
    return db;
}

@end




